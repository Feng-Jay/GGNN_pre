package java.util;
import org.checkerframework.checker.igj.qual.*;

@I
public class Stack<E> extends @I Vector<E> {
    private static final long serialVersionUID = 0L;
  public Stack() { throw new RuntimeException("skeleton method"); }
  public E push(@Mutable Stack<E> this, E a1) { throw new RuntimeException("skeleton method"); }
  public synchronized E pop(@Mutable Stack<E> this) { throw new RuntimeException("skeleton method"); }
  public synchronized E peek(@ReadOnly Stack<E> this) { throw new RuntimeException("skeleton method"); }
  public boolean empty(@ReadOnly Stack<E> this) { throw new RuntimeException("skeleton method"); }
  public synchronized int search(@ReadOnly Stack<E> this, @ReadOnly Object a1) { throw new RuntimeException("skeleton method"); }
}
