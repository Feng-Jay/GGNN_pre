package dcll.Ouss.mysimplestack;

public class Stack implements SimpleStack {

	private int size;
	
	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getSize() {
		// TODO Auto-generated method stub
		return size;
	}

	@Override
	public void push(Item item) {
		// TODO Auto-generated method stub

	}

	@Override
	public Item peek() throws EmptyStackException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Item pop() throws EmptyStackException {
		// TODO Auto-generated method stub
		return null;
	}

}
