/*
 * Copyright (C) 2017 jadovan
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package com.nasa;

/**
 * Project: NASA Path in conjunction with University of Maryland University
 * College
 *
 * @author jadovan
 */
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Dijkstra {
	private final List < Node > nodes;
	private final List < Edge > edges;
	private Set < Node > settledNodes;
	private Set < Node > unSettledNodes;
	private Map < Node,
	Node > predecessors;
	private Map < Node,
	Double > distance;

	public Dijkstra(Graph graph) {
		// create a copy of the array so that we can operate on this array
		this.nodes = new ArrayList < >(graph.getNodes());
		this.edges = new ArrayList < >(graph.getEdges());
	}

	public void execute(Node source) {
		settledNodes = new HashSet < >();
		unSettledNodes = new HashSet < >();
		distance = new HashMap < >();
		predecessors = new HashMap < >();
		distance.put(source, 0.0);
		unSettledNodes.add(source);
		while (unSettledNodes.size() > 0) {
			Node node = getMinimum(unSettledNodes);
			settledNodes.add(node);
			unSettledNodes.remove(node);
			findMinimalDistances(node);
		}
	}

	private void findMinimalDistances(Node node) {
		List < Node > adjacentNodes = getNeighbors(node);
		adjacentNodes.stream().filter((target) ->(getShortestDistance(target) > getShortestDistance(node) + getDistance(node, target))).map((target) ->{
			distance.put(target, getShortestDistance(node) + getDistance(node, target));
			return target;
		}).map((target) ->{
			predecessors.put(target, node);
			return target;
		}).forEachOrdered((target) ->{
			unSettledNodes.add(target);
		});

	}

	private double getDistance(Node node, Node target) {
		for (Edge edge: edges) {
			if (edge.getSource().equals(node) && edge.getDestination().equals(target)) {
				return edge.getWeight();
			}
		}
		throw new RuntimeException("Should not happen");
	}

	private List < Node > getNeighbors(Node node) {
		List < Node > neighbors = new ArrayList < >();
		edges.stream().filter((edge) ->(edge.getSource().equals(node) && !isSettled(edge.getDestination()))).forEachOrdered((edge) ->{
			neighbors.add(edge.getDestination());
		});
		return neighbors;
	}

	private Node getMinimum(Set < Node > nodes) {
		Node minimum = null;
		for (Node node: nodes) {
			if (minimum == null) {
				minimum = node;
			} else {
				if (getShortestDistance(node) < getShortestDistance(minimum)) {
					minimum = node;
				}
			}
		}
		return minimum;
	}

	private boolean isSettled(Node node) {
		return settledNodes.contains(node);
	}

	private double getShortestDistance(Node destination) {
		Double d = distance.get(destination);
		if (d == null) {
			return Double.MAX_VALUE;
		} else {
			return d;
		}
	}

	/*
     * This method returns the path from the source to the selected target and
     * NULL if no path exists
     */
	public LinkedList < Node > getPath(Node target) {
		LinkedList < Node > path = new LinkedList < >();
		Node step = target;
		// check if a path exists
		if (predecessors.get(step) == null) {
			return null;
		}
		path.add(step);
		while (predecessors.get(step) != null) {
			step = predecessors.get(step);
			path.add(step);
		}
		// Put it into the correct order
		Collections.reverse(path);
		return path;
	}
}