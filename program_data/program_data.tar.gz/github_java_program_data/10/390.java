	
	    static dfs()
	    {
	        java.util.regex.Pattern.compile("([a-zA-Z0-9-!#$%&\'*+.^_`{|}~]+)/([a-zA-Z0-9-!#$%&\'*+.^_`{|}~]+)");
	        java.util.regex.Pattern.compile(";\\s*(?:([a-zA-Z0-9-!#$%&\'*+.^_`{|}~]+)=(?:([a-zA-Z0-9-!#$%&\'*+.^_`{|}~]+)|\"([^\"]*)\"))?");
	        return;
	    }
	
	
	    public final boolean equals(Object p3)
	    {
	        if ((!(p3 instanceof dfs)) || (!0.equals(0))) {
	            int v0_2 = 0;
	        } else {
	            v0_2 = 1;
	        }
	        return v0_2;
	    }
	
	
	    public final int hashCode()
	    {
	        return 0.hashCode();
	    }
	
	
	    public final String toString()
	    {
	        return 0;
	    }
	
