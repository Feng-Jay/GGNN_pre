import java.util.regex.Pattern;

public final class dfs
{
  static
  {
    Pattern.compile("([a-zA-Z0-9-!#$%&'*+.^_`{|}~]+)/([a-zA-Z0-9-!#$%&'*+.^_`{|}~]+)");
    Pattern.compile(";\\s*(?:([a-zA-Z0-9-!#$%&'*+.^_`{|}~]+)=(?:([a-zA-Z0-9-!#$%&'*+.^_`{|}~]+)|\"([^\"]*)\"))?");
  }
  
  public final boolean equals(Object paramObject)
  {
    if ((paramObject instanceof dfs)) {
      throw new NullPointerException();
    }
    for (;;)
    {
      return false;
    }
  }
  
  public final int hashCode()
  {
    throw new NullPointerException();
  }
  
  public final String toString()
  {
    return null;
  }
}


/* Location:              C:\DEV\android\dex2jar-2.1-SNAPSHOT\classes-dex2jar.jar!\dfs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */