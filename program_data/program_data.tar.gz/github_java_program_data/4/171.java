import java.util.Arrays;

public class HashFunction {

  String[] theArray;
  int arraySize;
  int itemsInArray = 0;
  
  
  public static void main(String[] args) {
  
  }

  public void hashFunction1(String[] stringsForArray, String[] the Array){
    for (int n = 0; n < stringsForArray.length; n++) {
    String new ElementVal = stringsForArray[n];
    theArray[Integer.parseInt(newElementVal)] = newElementVal;
  }

  HashFunction(int size) { 
    theArray = new String[size];
    Arrays.fill(theArray, "-1");
  
}

public void displayTheStack() {

      int increment = 0;
      
