/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Theory;

import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

/**
 *
 * @author Zhang
 */
public class List_LinkedList {

    public static void main(String[] args) {
        /*
            LINKEDLIST
                - Là 1 class implements DQUEUE, extends AbstractSequentialList
                - LinkedList là 1 class tuân thủ theo Linked List truyền thống: FIFO (vào trước ra trước)
                - 
         */
//        Queue linkedList =new LinkedList(); khai báo ntn, hoặc như ở dưới
        List linkedList = new LinkedList();
//        linkedList. 
//  Tự demo hàm 
    }
}
